import 'package:flutter/material.dart';

class Constants {

  static var primaryColor = const Color(0xff296e48);
  static var blackColor = Colors.black54;}